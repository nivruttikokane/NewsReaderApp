//
//  NewsReaderAppTests.swift
//  NewsReaderAppTests
//
//  Created by Nivrutti Kokane on 08/10/24.
//

import XCTest
@testable import NewsReaderApp


@MainActor
final class NewsReaderAppTests: XCTestCase {

     var articleNewsVM = ArticleNewsViewModel()
    var newsAPIService: NewsAPI!

        override func setUpWithError() throws {
            newsAPIService = NewsAPI.shared
        }

        override func tearDownWithError() throws {
            newsAPIService = nil
        }
    
    //Testing Network Layer with Async/Await
    // Test successful API call using async/await
       func testFetchNewsSuccess() async throws {
           // Simulate network call
           Constants.apiKey = "a08f760a369744be8803ed5e0e2d979d"
           Constants.generateNewsURL = "https://newsapi.org/v2/top-headlines?"
           let articles = try await newsAPIService.fetch(from: .general)
           // Assert that articles are fetched successfully
           XCTAssertGreaterThan(articles.count, 0, "Articles should not be empty.")
       }
   /*
    func testFetchNewsSuccessForViewModel() async throws {
        // Simulate network call
        Constants.apiKey = "a08f760a369744be8803ed5e0e2d979d"
        Constants.generateNewsURL = "https://newsapi.org/v2/top-headlines?"
        let articles = try await articleNewsVM.loadArticles()
        print("articles : \(articles)")
        // Assert that articles are fetched successfully
      //  XCTAssertGreaterThan(articles.count, 0, "Articles should not be empty.")
    }
    */
    func testFetchArticleSuccess() async throws {
        // Simulate network call
        Constants.apiKey = "a08f760a369744be8803ed5e0e2d979d"
        Constants.generateNewsURL = "https://newsapi.org/v2/top-headlines?"
        let endString = "&language=en&category=general"
        var url = Constants.generateNewsURL
        url += "apiKey=\(Constants.apiKey)\(endString)"
        let newUrl : URL? = URL(string: url)
        guard let tempUrl  = newUrl else { return }
        let articles = try await newsAPIService.fetchArticles(from:tempUrl)
        // Assert that articles are fetched successfully
        XCTAssertGreaterThan(articles.count, 0, "Articles should not be empty.")
    }
    
    func testFetchNewsFailWhenUrlIsEmptyString() async throws {
        Constants.apiKey = "a08f760a369744be8803ed5e0e2d979d"
        Constants.generateNewsURL = ""
        do {
            _  = try await newsAPIService.fetch(from: .general)
            XCTFail("Expected failure, but succeeded.")
        } catch {
            XCTAssertNotNil(error, "Expected an error but got nil.")
        }
    }
    
    func testFetchNewsFailWhenAPIKeyIsEmptyString() async throws {
        Constants.apiKey = ""
        Constants.generateNewsURL = "https://newsapi.org/v2/top-headlines?"
        do {
            _  = try await newsAPIService.fetch(from: .general)
            XCTFail("Expected failure, but succeeded.")
        } catch {
            XCTAssertNotNil(error, "Expected an error but got nil.")
        }
    }
    
    func testFetchArticleFailWhenUrlIsEmptyString() async throws {
        Constants.apiKey = "a08f760a369744be8803ed5e0e2d979d"
        Constants.generateNewsURL = ""
        let url : URL? = URL(string: Constants.apiKey)
        guard let url  = url else { return }
        do {
            _  = try await newsAPIService.fetchArticles(from:url)
            XCTFail("Expected failure, but succeeded.")
        } catch {
            XCTAssertNotNil(error, "Expected an error but got nil.")
        }
    }
    
    func testFetchArticleFailWhenAPIKeyIsEmptyString() async throws {
        Constants.apiKey = ""
        Constants.generateNewsURL = "https://newsapi.org/v2/top-headlines?"
        let url : URL? = URL(string: Constants.generateNewsURL)
        guard let url  = url else { return }
        do {
            _  = try await newsAPIService.fetchArticles(from:url)
            XCTFail("Expected failure, but succeeded.")
        } catch {
            XCTAssertNotNil(error, "Expected an error but got nil.")
        }
    }

}


