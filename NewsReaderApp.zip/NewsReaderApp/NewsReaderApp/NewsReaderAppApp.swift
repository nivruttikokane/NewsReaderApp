//
//  NewsReaderAppApp.swift
//  NewsReaderApp
//
//  Created by Nivrutti Kokane on 08/10/24.
//

import SwiftUI

@main
struct NewsReaderAppApp: App {
    @StateObject var articleBookmarkVM = ArticleBookmarkViewModel.shared
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(articleBookmarkVM)
        }
    }
}
