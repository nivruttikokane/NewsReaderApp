//
//  Constants.swift
//  NewsReaderApp
//
//  Created by Nivrutti Kokane on 08/10/24.
//

struct Constants{
    //For testing purpose, I have used var when declaring constant variable otherwise I will use let here
    static var generateSearchURL: String = "https://newsapi.org/v2/everything?"
    static var apiKey: String = "a08f760a369744be8803ed5e0e2d979d"
    static var generateNewsURL: String = "https://newsapi.org/v2/top-headlines?"
    
   
}
